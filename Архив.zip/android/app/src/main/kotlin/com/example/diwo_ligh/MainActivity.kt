package com.example.diwo_ligh

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
